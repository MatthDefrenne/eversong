
#ifndef ___mega_marshal_MARSHAL_H__
#define ___mega_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

G_END_DECLS

#endif /* ___mega_marshal_MARSHAL_H__ */

