// This is configuration file containing test account credentials

const USERNAME = "fill-me-baby";
const PASSWORD = "fill-me-too";
